// test_pipeline — three stages against the mock source, unpaced, then a
// stop request. Proves: partial reads honored, retained-slot backpressure,
// producer-done drain (no lost frames after stop), every slot back in its
// pool, zero protocol violations, and the detector actually fires on the
// mock's bursts at the expected SNR.
#ifndef RF_IMPORT_STD
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>
#endif

#ifdef RF_IMPORT_STD
import std;
#endif
import rf.core;
import rf.memory;
import rf.runtime;
import rf.acquire;
import rf.pipeline;

#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "CHECK failed: %s (%s:%d)\n", #cond, __FILE__, __LINE__); std::exit(1); } } while (0)

int main(int argc, char** argv) {
    const double seconds = (argc > 1) ? std::atof(argv[1]) : 2.0;

    rf::acquire::MockSource source(/*realtime=*/false);
    rf::acquire::ReceiverConfig rc{};
    rc.center_frequency_hz = 800.0e6;
    rc.sample_rate_sps     = 30.72e6;
    rc.bandwidth_hz        = 28.0e6;
    rc.gain_db             = 40.0f;
    rc.receiver_id         = 7;
    CHECK(source.configure(rc));

    rf::runtime::StageState state;
    rf::pipeline::PipelineSystem pipeline(source, state);
    CHECK(pipeline.initialize(rf::memory::UnlockedRegionConfig) == rf::memory::MemoryError::none);
    CHECK(pipeline.ready());
    CHECK(source.start());

    std::thread acq([&] { pipeline.run_acquisition(); });
    std::thread dsp([&] { pipeline.run_dsp(); });
    std::thread sink([&] { pipeline.run_sink(); });

    std::this_thread::sleep_for(std::chrono::duration<double>(seconds));
    state.request_stop();
    acq.join(); dsp.join(); sink.join();
    source.stop();
    pipeline.reclaim_held_slots();

    const auto captured  = state.frames_captured.load();
    const auto processed = state.frames_processed.load();
    const auto dropped   = state.dsp_backpressure.load();

    std::printf("captured=%llu processed=%llu partial=%llu timeouts=%llu overruns=%llu "
                "backpressure=%llu pool_exhausted=%llu candidates=%llu emitted=%llu consumed=%llu "
                "event_backpressure=%llu event_pool_exhausted=%llu floor=%.1f dB last_snr=%.1f dB\n",
                (unsigned long long)captured, (unsigned long long)processed,
                (unsigned long long)state.frames_partial.load(),
                (unsigned long long)state.rx_timeouts.load(),
                (unsigned long long)state.rx_overruns.load(),
                (unsigned long long)dropped,
                (unsigned long long)state.capture_pool_exhausted.load(),
                (unsigned long long)state.candidates.load(),
                (unsigned long long)state.events_emitted.load(),
                (unsigned long long)state.events_consumed.load(),
                (unsigned long long)state.event_backpressure.load(),
                (unsigned long long)state.event_pool_exhausted.load(),
                pipeline.noise_floor_db(), pipeline.last_snr_db());

    CHECK(captured > 0);
    CHECK(processed == captured);                          // drain semantics: nothing lost after stop
    CHECK(state.events_consumed.load() == state.events_emitted.load());
    CHECK(state.protocol_violations.load() == 0);
    CHECK(pipeline.capture_slots_free() == rf::pipeline::Topology::CapturePoolDepth);
    CHECK(pipeline.scratch_slots_free() == rf::pipeline::Topology::ScratchDepth);
    CHECK(pipeline.event_slots_free()   == rf::pipeline::Topology::EventPoolDepth);
    CHECK(state.acquisition_done.load() && state.dsp_done.load() && state.sink_done.load());
    if (captured >= 10) {
        CHECK(state.frames_partial.load() > 0);           // every 5th mock read is partial
        CHECK(state.candidates.load() > 0);               // bursts detected relative to the tracked floor
        CHECK(pipeline.noise_floor_db() < -40.0f && pipeline.noise_floor_db() > -52.0f);
        CHECK(pipeline.last_snr_db() > 10.0f && pipeline.last_snr_db() < 30.0f);
    }
    std::puts("test_pipeline: PASS");
    return 0;
}
