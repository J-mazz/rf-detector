// rfdet — pipeline host. v0 runs the deterministic mock source; the
// SoapySDR adapter (rf.acquire::SoapySource) slots in behind the same
// SDRSource interface.
#ifndef RF_IMPORT_STD
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>
#endif
#include <signal.h>

#ifdef RF_IMPORT_STD
import std;
#endif
import rf.core;
import rf.memory;
import rf.runtime;
import rf.acquire;
import rf.pipeline;

namespace {

volatile sig_atomic_t g_signalled = 0;
void on_signal(int) { g_signalled = 1; }

const char* mem_error_name(rf::memory::MemoryError e) {
    using E = rf::memory::MemoryError;
    switch (e) {
        case E::none:            return "none";
        case E::invalid_size:    return "invalid_size";
        case E::mmap_failed:     return "mmap_failed";
        case E::mlock_failed:    return "mlock_failed";
        case E::memlock_budget:  return "memlock_budget (raise RLIMIT_MEMLOCK: LimitMEMLOCK= in the unit)";
        case E::not_initialized: return "not_initialized";
    }
    return "?";
}

} // namespace

int main(int argc, char** argv) {
    double seconds = 3.0;
    bool lock = true;
    bool realtime = true;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--seconds") == 0 && i + 1 < argc) seconds = std::atof(argv[++i]);
        else if (std::strcmp(argv[i], "--no-lock") == 0) lock = false;
        else if (std::strcmp(argv[i], "--unpaced") == 0) realtime = false;
    }

    rf::acquire::MockSource source(realtime);
    rf::acquire::ReceiverConfig rc{};
    rc.center_frequency_hz = 800.0e6;    // 785–815 MHz public-safety uplink window (DESIGN.md §1)
    rc.sample_rate_sps     = 30.72e6;
    rc.bandwidth_hz        = 28.0e6;
    rc.gain_db             = 40.0f;
    rc.receiver_id         = 0;
    if (!source.configure(rc)) { std::fputs("configure failed\n", stderr); return 2; }

    rf::runtime::StageState state;
    rf::pipeline::PipelineSystem pipeline(source, state);

    rf::memory::RegionConfig region = lock ? rf::memory::DefaultRegionConfig
                                           : rf::memory::UnlockedRegionConfig;
    std::printf("locked bytes required: %zu (RLIMIT_MEMLOCK soft limit: %zu)\n",
                rf::pipeline::PipelineSystem::locked_bytes_required(),
                rf::memory::memlock_limit_bytes());
    if (auto e = pipeline.initialize(region); e != rf::memory::MemoryError::none) {
        std::fprintf(stderr, "pool initialization failed: %s\n", mem_error_name(e));
        return 3;
    }

    ::signal(SIGINT, on_signal);
    ::signal(SIGTERM, on_signal);
    if (!source.start()) return 4;

    std::thread acq([&] { pipeline.run_acquisition(); });
    std::thread dsp([&] { pipeline.run_dsp(); });
    std::thread sink([&] { pipeline.run_sink(); });

    const auto t0 = std::chrono::steady_clock::now();
    while (!g_signalled &&
           std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() < seconds) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    state.request_stop();
    acq.join(); dsp.join(); sink.join();
    source.stop();
    pipeline.reclaim_held_slots();

    std::printf("frames captured=%llu processed=%llu partial=%llu\n"
                "rx overruns=%llu timeouts=%llu failures=%llu pool_exhausted=%llu backpressure=%llu\n"
                "candidates=%llu events emitted=%llu consumed=%llu event_pool_exhausted=%llu event_backpressure=%llu\n"
                "noise floor=%.1f dB  last event SNR=%.1f dB\n"
                "free slots: capture=%zu/%zu scratch=%zu/%zu event=%zu/%zu  protocol violations=%llu\n",
                (unsigned long long)state.frames_captured.load(),
                (unsigned long long)state.frames_processed.load(),
                (unsigned long long)state.frames_partial.load(),
                (unsigned long long)state.rx_overruns.load(),
                (unsigned long long)state.rx_timeouts.load(),
                (unsigned long long)state.rx_failures.load(),
                (unsigned long long)state.capture_pool_exhausted.load(),
                (unsigned long long)state.dsp_backpressure.load(),
                (unsigned long long)state.candidates.load(),
                (unsigned long long)state.events_emitted.load(),
                (unsigned long long)state.events_consumed.load(),
                (unsigned long long)state.event_pool_exhausted.load(),
                (unsigned long long)state.event_backpressure.load(),
                pipeline.noise_floor_db(), pipeline.last_snr_db(),
                pipeline.capture_slots_free(), rf::pipeline::Topology::CapturePoolDepth,
                pipeline.scratch_slots_free(), rf::pipeline::Topology::ScratchDepth,
                pipeline.event_slots_free(),   rf::pipeline::Topology::EventPoolDepth,
                (unsigned long long)state.protocol_violations.load());
    return state.protocol_violations.load() == 0 ? 0 : 5;
}
