// rf.dsp — deterministic front end. Knows nothing about inference, Qt,
// storage, or transport.
//
// v0 contains the energy detector only. Channelization/STFT, which the LE
// fingerprint work needs for the 785–815 MHz uplink window, lands here next;
// it must consume PlanarIQBlock and emit SpectralCandidate exactly as this
// detector does, so nothing downstream changes.
module;
#include <version>
#ifndef RF_IMPORT_STD
#include <cmath>
#include <cstddef>
#include <cstdint>
#endif

export module rf.dsp;

#ifdef RF_IMPORT_STD
import std;
#endif
import rf.core;
import rf.signal;

export namespace rf::dsp {

// Asymmetric exponential tracker in the log domain: follows the floor down
// quickly and up slowly, and is frozen while a chunk is above threshold, so
// a long burst cannot drag the estimate up into itself.
struct NoiseTracker {
    float floor_db;
    float alpha_up;
    float alpha_down;
    bool  seeded;

    static constexpr NoiseTracker make(float alpha_up = 0.005f, float alpha_down = 0.2f) noexcept {
        return NoiseTracker{0.0f, alpha_up, alpha_down, false};
    }

    void observe(float chunk_db, bool above_threshold) noexcept {
        if (!seeded) { floor_db = chunk_db; seeded = true; return; }
        if (above_threshold) return;
        const float a = (chunk_db < floor_db) ? alpha_down : alpha_up;
        floor_db += a * (chunk_db - floor_db);
    }
};

struct EnergyDetectorConfig {
    std::size_t chunk_complex;    // samples per decision
    float       threshold_db;     // energy above tracked floor
    float       alpha_up;
    float       alpha_down;
};
inline constexpr EnergyDetectorConfig DefaultEnergyDetector{1024, 10.0f, 0.005f, 0.2f};

// Converts mean |x|^2 to dB with a floor that keeps log10 finite for an
// all-zero chunk (the mock and a disconnected front end both produce them).
[[nodiscard]] inline float mean_power_db(float energy, std::size_t count) noexcept {
    const float mean = energy / static_cast<float>(count);
    return 10.0f * std::log10(mean > 1e-20f ? mean : 1e-20f);
}

template <typename Backend>
class EnergyDetector {
public:
    explicit EnergyDetector(EnergyDetectorConfig cfg = DefaultEnergyDetector) noexcept
        : cfg_(cfg), tracker_(NoiseTracker::make(cfg.alpha_up, cfg.alpha_down)) {}

    // Scans `block` chunk by chunk. `magsq_scratch` must hold at least
    // cfg.chunk_complex floats (a scratch-pool plane, never a stack array).
    // Writes up to `max_out` candidates; returns how many were written.
    // Chunks beyond max_out are still observed by the tracker.
    [[nodiscard]] std::size_t scan(const rf::signal::PlanarIQBlock& block,
                                   float* magsq_scratch,
                                   rf::signal::SpectralCandidate* out,
                                   std::size_t max_out,
                                   rf::core::TimestampNs now_ns) noexcept
    {
        const std::size_t chunk = cfg_.chunk_complex;
        const std::size_t chunks = block.count_complex / chunk;    // trailing partial chunk ignored
        std::size_t written = 0;
        const float fs = static_cast<float>(block.meta.sample_rate_sps);

        for (std::size_t c = 0; c < chunks; ++c) {
            const std::size_t off = c * chunk;
            Backend::magnitude_squared(block.i + off, block.q + off, magsq_scratch, chunk);
            const float energy_db = mean_power_db(Backend::sum(magsq_scratch, chunk), chunk);

            const bool above = tracker_.seeded && (energy_db - tracker_.floor_db > cfg_.threshold_db);
            tracker_.observe(energy_db, above);

            if (above && written < max_out) {
                rf::signal::SpectralCandidate& cand = out[written++];
                cand.bin_begin        = 0;                           // wideband decision: whole window
                cand.bin_end          = 1;
                cand.chunk_index      = static_cast<std::uint32_t>(c);
                cand.reserved0        = 0;
                cand.energy_db        = energy_db;
                cand.noise_floor_db   = tracker_.floor_db;
                cand.snr_db           = energy_db - tracker_.floor_db;
                cand.center_offset_hz = 0.0f;
                cand.bandwidth_hz     = fs;
                cand.duration_s       = (fs > 0.0f) ? static_cast<float>(chunk) / fs : 0.0f;
                cand.detected_at_ns   = now_ns;
            }
        }
        return written;
    }

    [[nodiscard]] float noise_floor_db() const noexcept { return tracker_.floor_db; }
    [[nodiscard]] const EnergyDetectorConfig& config() const noexcept { return cfg_; }

private:
    EnergyDetectorConfig cfg_;
    NoiseTracker         tracker_;
};

} // namespace rf::dsp
