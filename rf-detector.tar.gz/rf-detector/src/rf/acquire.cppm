// rf.acquire — device intake. The interface mirrors SoapySDR::Device::
// readStream semantics (caller-owned destination, partial reads, timeout /
// overflow as status codes) so the SoapySDR implementation for bladeRF /
// LimeSDR / USRP is a thin adapter, and the device writes straight into a
// pinned capture slot — no library buffer, no memcpy.
module;
#include <version>
#ifndef RF_IMPORT_STD
#include <cmath>
#include <cstddef>
#include <cstdint>
#endif

export module rf.acquire;

#ifdef RF_IMPORT_STD
import std;
#endif
import rf.core;

export namespace rf::acquire {

using rf::core::FrequencyHz;
using rf::core::SampleRateSps;

enum class ReadStatus : std::uint8_t { ok, timeout, overflow, failure, stopped };

struct ReadResult {
    std::size_t  complex_samples;   // valid complex samples written to the destination
    ReadStatus   status;
    std::int64_t hw_time_ns;        // device timestamp of the first sample, or 0
};

struct ReceiverConfig {
    FrequencyHz   center_frequency_hz;
    SampleRateSps sample_rate_sps;
    double        bandwidth_hz;
    float         gain_db;
    std::uint32_t receiver_id;
};

class SDRSource {
public:
    // Out-of-line: gives the vtable and destructor a single home TU (this
    // module). Also sidesteps a GCC 14 modules ICE on defaulted virtual dtors.
    virtual ~SDRSource() noexcept;

    [[nodiscard]] virtual bool configure(const ReceiverConfig& cfg) noexcept = 0;
    [[nodiscard]] virtual bool start() noexcept = 0;
    virtual void stop() noexcept = 0;

    // Writes up to `capacity_complex` interleaved int16 I/Q pairs into
    // `interleaved`. May return fewer (partial read) — the count returned
    // is the only source of truth for validity.
    [[nodiscard]] virtual ReadResult read_into(std::int16_t* interleaved,
                                               std::size_t capacity_complex,
                                               std::uint32_t timeout_us) noexcept = 0;

    [[nodiscard]] virtual const ReceiverConfig& config() const noexcept = 0;
};

// Deterministic mock: uniform noise at about -46 dBFS with a periodic tone
// burst about 22 dB above it, partial reads every 5th frame, a timeout every
// 97th and an overflow every 101st read. `realtime` paces reads at the
// configured sample rate so main() behaves like a device; tests run unpaced.
class MockSource final : public SDRSource {
public:
    explicit MockSource(bool realtime = false, std::uint64_t seed = 0x9E3779B97F4A7C15ull) noexcept
        : realtime_(realtime), rng_(seed) {}

    [[nodiscard]] bool configure(const ReceiverConfig& cfg) noexcept override {
        cfg_ = cfg;
        const double w = 2.0 * 3.14159265358979323846 * (cfg.sample_rate_sps * 0.05) / cfg.sample_rate_sps;
        rot_re_ = std::cos(w);
        rot_im_ = std::sin(w);
        return cfg.sample_rate_sps > 0.0;
    }
    [[nodiscard]] bool start() noexcept override { running_ = true; return true; }
    void stop() noexcept override { running_ = false; }

    [[nodiscard]] ReadResult read_into(std::int16_t* dst, std::size_t capacity_complex,
                                       std::uint32_t) noexcept override
    {
        if (!running_) return {0, ReadStatus::stopped, 0};
        const std::uint64_t n = ++reads_;
        if (n % 97 == 0)  return {0, ReadStatus::timeout, 0};
        if (n % 101 == 0) return {0, ReadStatus::overflow, 0};

        const std::size_t count = (n % 5 == 0) ? (capacity_complex * 3) / 5 : capacity_complex;
        const bool burst = (n % 7 == 3);
        const std::size_t b0 = count / 8, b1 = count / 2;

        float ph_re = 1.0f, ph_im = 0.0f;
        for (std::size_t k = 0; k < count; ++k) {
            int i = noise(); int q = noise();
            if (burst && k >= b0 && k < b1) {
                i += static_cast<int>(2000.0f * ph_re);
                q += static_cast<int>(2000.0f * ph_im);
                const float re = ph_re * rot_re_ - ph_im * rot_im_;
                const float im = ph_re * rot_im_ + ph_im * rot_re_;
                ph_re = re; ph_im = im;
                if ((k & 1023u) == 0) {                       // renormalize the phasor
                    const float m = std::sqrt(ph_re * ph_re + ph_im * ph_im);
                    if (m > 0.0f) { ph_re /= m; ph_im /= m; }
                }
            }
            dst[2 * k]     = static_cast<std::int16_t>(i);
            dst[2 * k + 1] = static_cast<std::int16_t>(q);
        }

        if (realtime_ && cfg_.sample_rate_sps > 0.0) {
            const double secs = static_cast<double>(count) / cfg_.sample_rate_sps;
            rf::core::sleep_ns(static_cast<std::uint64_t>(secs * 1e9));
        }
        const std::int64_t hw = static_cast<std::int64_t>(sample_clock_ * (1e9 / cfg_.sample_rate_sps));
        sample_clock_ += count;
        return {count, ReadStatus::ok, hw};
    }

    [[nodiscard]] const ReceiverConfig& config() const noexcept override { return cfg_; }

private:
    [[nodiscard]] int noise() noexcept {          // uniform in [-200, 200]
        rng_ ^= rng_ << 13; rng_ ^= rng_ >> 7; rng_ ^= rng_ << 17;
        return static_cast<int>(rng_ % 401u) - 200;
    }

    bool           realtime_;
    bool           running_{false};
    std::uint64_t  rng_;
    std::uint64_t  reads_{0};
    std::uint64_t  sample_clock_{0};
    float          rot_re_{1.0f};
    float          rot_im_{0.0f};
    ReceiverConfig cfg_{};
};

SDRSource::~SDRSource() noexcept = default;

} // namespace rf::acquire
