// rf.signal — dataplane record layouts.
//
// Every type here is an OverwriteRecord (rf.core): no default member
// initializers, no constructors, no destructors. Storage is established
// once; producers write every field they claim is valid. `zero()`
// factories exist for control-plane convenience only.
module;
#include <version>
#ifndef RF_IMPORT_STD
#include <cstddef>
#include <cstdint>
#endif

export module rf.signal;

#ifdef RF_IMPORT_STD
import std;
#endif
import rf.core;

export namespace rf::signal {

using rf::core::CacheLineSize;
using rf::core::FrequencyHz;
using rf::core::SampleRateSps;
using rf::core::TimestampNs;
using rf::core::WallNs;

// Units convention: `_complex` counts complex (I,Q) samples. An interleaved
// int16 buffer holding N complex samples has 2N scalar elements.

struct CaptureMetadata {
    TimestampNs   timestamp_ns;        // monotonic, at read completion
    WallNs        wall_ns;             // system clock, same instant (GPS/log correlation)
    std::int64_t  hw_time_ns;          // device timestamp if provided, else 0
    FrequencyHz   center_frequency_hz;
    SampleRateSps sample_rate_sps;
    float         gain_db;
    std::uint32_t receiver_id;
    std::uint64_t sequence;            // frame counter, per receiver
    std::uint32_t dropped_frames_prior; // frames lost since the previous delivered frame
    std::uint32_t reserved0;

    static constexpr CaptureMetadata zero() noexcept { return CaptureMetadata{}; }
};
static_assert(rf::core::OverwriteRecord<CaptureMetadata>);

// Non-owning view of a capture slot. `valid_complex` is established by the
// producer from the device's actual return count — never from capacity.
struct RawCaptureBlock {
    std::int16_t*   interleaved;        // I0 Q0 I1 Q1 ...
    std::size_t     capacity_complex;
    std::size_t     valid_complex;
    CaptureMetadata meta;
};
static_assert(rf::core::OverwriteRecord<RawCaptureBlock>);

// Non-owning planar (SoA) view over a scratch slot.
struct PlanarIQBlock {
    float*          i;
    float*          q;
    std::size_t     capacity_complex;
    std::size_t     count_complex;
    CaptureMetadata meta;
};
static_assert(rf::core::OverwriteRecord<PlanarIQBlock>);

// Bin ranges are half-open: [bin_begin, bin_end).
struct SpectralCandidate {
    std::uint32_t bin_begin;
    std::uint32_t bin_end;
    std::uint32_t chunk_index;         // position within the frame, in detector chunks
    std::uint32_t reserved0;
    float         energy_db;           // 10*log10(mean |x|^2) over the candidate
    float         noise_floor_db;      // tracker estimate at detection time
    float         snr_db;              // energy_db - noise_floor_db
    float         center_offset_hz;    // relative to CaptureMetadata::center_frequency_hz
    float         bandwidth_hz;
    float         duration_s;
    TimestampNs   detected_at_ns;

    static constexpr SpectralCandidate zero() noexcept { return SpectralCandidate{}; }
};
static_assert(rf::core::OverwriteRecord<SpectralCandidate>);

// Event tensor layout invariant (also the ONNX/TensorRT input contract):
//   time-major, data[hop * Bins + bin]; bins contiguous.
//   Model input shape: [1, 1, Hops, Bins] (N, C, H=time, W=frequency).
//   Quantization: value_db = scale * (q - zero_point), symmetric int8.
inline constexpr std::size_t SpectrogramBins = 128;
inline constexpr std::size_t SpectrogramHops = 32;

struct TensorQuant {
    float       scale;                 // dB per LSB
    std::int8_t zero_point;
    std::int8_t reserved0[3];
};
static_assert(rf::core::OverwriteRecord<TensorQuant>);

struct EventTensor {
    static constexpr std::size_t Hops = SpectrogramHops;
    static constexpr std::size_t Bins = SpectrogramBins;
    static constexpr std::size_t Elements = Hops * Bins;

    alignas(CacheLineSize) std::int8_t data[Elements];   // overwrite-only; never zeroed on reuse

    [[nodiscard]] static constexpr std::size_t index(std::size_t hop, std::size_t bin) noexcept {
        return hop * Bins + bin;
    }
    [[nodiscard]] std::int8_t* row(std::size_t hop) noexcept { return data + hop * Bins; }
};
static_assert(rf::core::OverwriteRecord<EventTensor>);
static_assert(sizeof(EventTensor) == SpectrogramBins * SpectrogramHops);

struct CandidateEvent {
    std::uint64_t     event_id;
    TimestampNs       timestamp_ns;
    WallNs            wall_ns;
    CaptureMetadata   source_meta;
    SpectralCandidate detection;
    TensorQuant       quant;
    std::uint32_t     tensor_valid_hops;   // rows of `tensor` actually written
    EventTensor       tensor;
};
static_assert(rf::core::OverwriteRecord<CandidateEvent>);
static_assert(sizeof(CandidateEvent) % CacheLineSize == 0,
              "CandidateEvent must tile cache lines for ObjectPool");

} // namespace rf::signal
